fx_version 'cerulean'
games {'gta5'}
lua54 'yes'

author 'Atlas Studios'
description 'System Blip V2'
version '1.0.0'

-- What to run
shared_script '@es_extended/imports.lua'
client_script 'blips.lua'

escrow_ignore {
    'client/*.lua',     -- Ignore all .yft files in that folder
  }

dependency '/assetpacks'