ESX = exports["es_extended"]:getSharedObject()


	local blips = {
    {title="SuperStar Cafe", scale=0.9, colour=63, id=93, x=4.1,y=542.9,z=15.7},
    {title="Apple Store", scale=0.9, colour=2, id=521, x=72.89,y=717.04,z=14.9},
    {title="Cluckin' Bell", scale=0.9, colour=46, id=93, x=111.42,y=562.36,z=14.8},
    {title="Bowling", scale=0.9, colour=43, id=515, x=1437.43,y=-164.69,z=22.13},
    {title="Honkers", scale=0.9, colour=8, id=93, x=-1326.84,y=504.26,z=10.01},
    {title="The Triangolo Club", scale=0.9, colour=8, id=93, x=1417.38,y=2185.68,z=16.72},
    {title="BurgerShot", scale=0.9, colour=1, id=93, x=1346.82,y=2080.82,z=16.9},
    {title="Police Station", scale=0.9, colour=29, id=60, x=1300.35,y=1363.69,z=30.82},
    
		}

Citizen.CreateThread(function()

    for _, info in pairs(blips) do
      info.blip = AddBlipForCoord(info.x, info.y, info.z)
      SetBlipSprite(info.blip, info.id)
      SetBlipDisplay(info.blip, 4)
      SetBlipScale(info.blip, info.scale)
      SetBlipColour(info.blip, info.colour)
      SetBlipAsShortRange(info.blip, true)
	  BeginTextCommandSetBlipName("STRING")
      AddTextComponentString(info.title)
      EndTextCommandSetBlipName(info.blip)
    end
end)

Citizen.CreateThread( function()
while true do
Citizen.Wait(500)
ResetPlayerStamina(PlayerId())
end
end)
